data文件夹下为实验数据，6个list分别为training acc/loss, validation acc/loss, testing acc/loss
为了输出数据，我在main函数中增加了数个record list容器，具体在75行前后
