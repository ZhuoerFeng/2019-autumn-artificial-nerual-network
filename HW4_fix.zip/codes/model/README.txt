Please download the model weights at
https://cloud.tsinghua.edu.cn/f/44ab9cee7cc64502bbeb/?dl=1